/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        saffron: {
          50: '#FFF7ED',
          100: '#FFEDD5',
          200: '#FED7AA',
          300: '#FDBA74',
          400: '#FB923C',
          500: '#E8560C',
          600: '#C2410C',
          700: '#9A3412',
          800: '#7C2D12',
          900: '#431407',
        },
        success: {
          50: '#ECFDF5',
          100: '#D1FAE5',
          500: '#138808',
          600: '#0D6E04',
        },
        navy: {
          700: '#1E3A5F',
          800: '#172B4D',
          900: '#0A1929',
        }
      },
      fontFamily: {
        sans: ['Noto Sans Devanagari', 'Noto Sans', 'sans-serif'],
      },
      fontSize: {
        'touch': '1.125rem',
      },
      minHeight: {
        'touch': '48px',
      },
      minWidth: {
        'touch': '48px',
      }
    },
  },
  plugins: [],
}
