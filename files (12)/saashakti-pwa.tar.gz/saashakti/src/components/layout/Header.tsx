import { useLang } from '../../hooks/useLang'
import type { FieldWorker } from '../../engine/types'
import { Globe } from 'lucide-react'

interface Props {
  fieldWorker?: FieldWorker | null
}

export default function Header({ fieldWorker }: Props) {
  const { lang, setLang, t } = useLang()

  return (
    <header className="bg-white border-b border-saffron-200 px-4 py-3 flex items-center justify-between sticky top-0 z-50">
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 bg-saffron-500 rounded-full flex items-center justify-center">
          <span className="text-white font-bold text-sm">स</span>
        </div>
        <div>
          <h1 className="text-lg font-bold text-saffron-700 leading-tight">{t('app_name')}</h1>
          {fieldWorker && (
            <p className="text-xs text-gray-500">{fieldWorker.name} — {fieldWorker.organization}</p>
          )}
        </div>
      </div>
      <button
        onClick={() => setLang(lang === 'hi' ? 'en' : 'hi')}
        className="flex items-center gap-1 px-3 py-2 rounded-lg bg-saffron-50 text-saffron-700 text-sm font-medium active:bg-saffron-100 min-h-touch"
      >
        <Globe size={16} />
        {lang === 'hi' ? 'EN' : 'हि'}
      </button>
    </header>
  )
}
