import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useLang } from '../hooks/useLang'
import { calculateTotalBenefit } from '../engine/matchSchemes'
import type { BeneficiaryProfile, FieldWorker, SchemeMatch } from '../engine/types'
import { CheckCircle, AlertCircle, IndianRupee, FileText, ExternalLink, UserPlus } from 'lucide-react'

interface Props {
  profile: BeneficiaryProfile | null
  matches: SchemeMatch[]
  fieldWorker: FieldWorker | null
  onRegisterNext: () => void
}

export default function ResultsPage({ profile, matches, fieldWorker, onRegisterNext }: Props) {
  const { t, lang } = useLang()
  const navigate = useNavigate()

  if (!profile) {
    navigate('/')
    return null
  }

  const eligible = matches.filter(m => m.eligibility_status === 'eligible')
  const partial = matches.filter(m => m.eligibility_status === 'partial')
  const totalBenefit = calculateTotalBenefit(matches)

  const handleRegisterNext = () => {
    onRegisterNext()
    navigate('/register')
  }

  return (
    <div className="pb-24">
      {/* Benefit Summary Card */}
      <div className="m-4 bg-gradient-to-br from-saffron-500 to-saffron-600 rounded-2xl p-5 text-white shadow-lg">
        <p className="text-saffron-100 text-sm mb-1">{profile.name}</p>
        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-4xl font-bold">
            {eligible.length + partial.length}
          </span>
          <span className="text-lg text-saffron-100">{t('schemes_matched')}</span>
        </div>
        {totalBenefit > 0 && (
          <div className="bg-white/20 rounded-xl px-4 py-3 flex items-center gap-2">
            <IndianRupee size={20} />
            <div>
              <p className="text-xs text-saffron-100">{t('total_benefit')}</p>
              <p className="text-2xl font-bold">₹{totalBenefit.toLocaleString('en-IN')}</p>
            </div>
            <span className="text-saffron-100 text-sm ml-auto">{t('per_year')}</span>
          </div>
        )}
      </div>

      {/* Eligible Schemes */}
      {eligible.length > 0 && (
        <div className="px-4 mb-4">
          <h2 className="text-lg font-semibold text-success-500 mb-3 flex items-center gap-2">
            <CheckCircle size={20} /> {t('eligible')} ({eligible.length})
          </h2>
          <div className="space-y-3">
            {eligible.map(m => <SchemeCard key={m.scheme_id} match={m} lang={lang} t={t} />)}
          </div>
        </div>
      )}

      {/* Partial Schemes */}
      {partial.length > 0 && (
        <div className="px-4 mb-4">
          <h2 className="text-lg font-semibold text-yellow-600 mb-3 flex items-center gap-2">
            <AlertCircle size={20} /> {t('partial')} ({partial.length})
          </h2>
          <div className="space-y-3">
            {partial.map(m => <SchemeCard key={m.scheme_id} match={m} lang={lang} t={t} />)}
          </div>
        </div>
      )}

      {/* Field Worker: Register Next */}
      {fieldWorker && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-saffron-200 p-4">
          <button onClick={handleRegisterNext}
            className="btn-success flex items-center justify-center gap-2">
            <UserPlus size={20} />
            {t('save_register_next')}
          </button>
        </div>
      )}
    </div>
  )
}

function SchemeCard({ match, lang, t }: { match: SchemeMatch, lang: string, t: (k: string) => string }) {
  const { scheme } = match
  const [expanded, setExpanded] = useState(false)
  
  const benefitText = scheme.benefit.amount
    ? `₹${scheme.benefit.amount.toLocaleString('en-IN')}`
    : ''

  const freqText = scheme.benefit.frequency === 'monthly' ? t('per_month')
    : scheme.benefit.frequency === 'annual' ? t('per_year')
    : scheme.benefit.frequency === 'one_time' || scheme.benefit.frequency === 'one_time_installments' ? t('one_time')
    : ''

  return (
    <div className="card" onClick={() => setExpanded(!expanded)}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <h3 className="font-semibold text-base leading-tight">
            {lang === 'hi' ? scheme.name_hi : scheme.name_en}
          </h3>
          <p className="text-sm text-gray-500 mt-0.5">{scheme.department_hi}</p>
        </div>
        <div className="text-right flex-shrink-0">
          {benefitText && (
            <p className="text-lg font-bold text-saffron-600">{benefitText}</p>
          )}
          <p className="text-xs text-gray-400">{freqText}</p>
        </div>
      </div>

      {/* Confidence badge */}
      <div className="mt-2">
        <span className={match.eligibility_status === 'eligible' ? 'badge-eligible' : 'badge-partial'}>
          {match.eligibility_status === 'eligible' ? `✅ ${t('eligible')}` : `⚠️ ${t('partial')}`}
        </span>
      </div>

      {/* Explanation */}
      <p className="text-sm text-gray-600 mt-2">
        {lang === 'hi' ? match.explanation_hi : match.explanation_en}
      </p>

      {/* Expanded details */}
      {expanded && (
        <div className="mt-3 pt-3 border-t border-saffron-100 space-y-3">
          {/* Benefit description */}
          <p className="text-sm">
            {lang === 'hi' ? scheme.benefit.description_hi : scheme.benefit.description_en}
          </p>

          {/* Documents */}
          <div>
            <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-1 mb-1">
              <FileText size={14} /> {t('documents_needed')}
            </h4>
            <ul className="text-sm text-gray-600 space-y-1">
              {scheme.documents_required.map((doc: string, i: number) => (
                <li key={i} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-saffron-300" />
                  {doc}
                </li>
              ))}
            </ul>
          </div>

          {/* Portal link */}
          {scheme.portal && (
            <a href={scheme.portal} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1 text-sm text-saffron-600 font-medium">
              <ExternalLink size={14} /> {t('how_to_apply')}
            </a>
          )}

          {/* Next action */}
          <p className="text-sm bg-saffron-50 rounded-lg px-3 py-2 text-saffron-700">
            → {match.next_best_action}
          </p>
        </div>
      )}
    </div>
  )
}

// Need this import for useState in SchemeCard
import { useState } from 'react'
