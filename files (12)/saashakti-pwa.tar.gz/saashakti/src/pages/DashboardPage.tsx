import { useState, useEffect } from 'react'
import { getDashboardStats, subscribeToDashboard } from '../lib/supabase'
import { useLang } from '../hooks/useLang'
import { Users, MapPin, Award, IndianRupee, Heart, Baby, Shield, TrendingUp } from 'lucide-react'

interface DashboardData {
  total_registrations: number
  districts: number
  total_matches: number
  total_benefit: number
  bpl_count: number
  pregnant_count: number
  widow_count: number
  by_district: [string, number][]
}

export default function DashboardPage() {
  const { t } = useLang()
  const [stats, setStats] = useState<DashboardData | null>(null)
  const [prevCount, setPrevCount] = useState(0)
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    // Initial fetch
    getDashboardStats().then(s => { if (s) setStats(s as DashboardData) })

    // Poll every 8 seconds (reliable, low overhead)
    const interval = setInterval(() => {
      getDashboardStats().then(s => { if (s) setStats(s as DashboardData) })
    }, 8000)

    // Also subscribe for instant updates
    const channel = subscribeToDashboard(() => {
      getDashboardStats().then(s => { if (s) setStats(s as DashboardData) })
    })

    return () => {
      clearInterval(interval)
      channel.unsubscribe()
    }
  }, [])

  // Animate counter on change
  useEffect(() => {
    if (stats && stats.total_registrations !== prevCount) {
      setAnimate(true)
      setPrevCount(stats.total_registrations)
      setTimeout(() => setAnimate(false), 600)
    }
  }, [stats?.total_registrations])

  if (!stats) {
    return (
      <div className="min-h-screen bg-navy-900 flex items-center justify-center">
        <div className="text-white text-xl animate-pulse">Loading Dashboard...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-900 via-navy-800 to-saffron-900 text-white p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-saffron-500 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-xl">स</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold">सशक्ति — Saashakti</h1>
            <p className="text-saffron-300 text-sm">महिला कल्याण योजना मिलान मंच</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-400 live-pulse" />
          <span className="text-green-400 text-sm font-medium">LIVE</span>
        </div>
      </div>

      {/* Main Counter */}
      <div className="text-center mb-10">
        <p className="text-saffron-300 text-lg mb-2">{t('total_registered')}</p>
        <div className={`text-8xl font-bold text-white tracking-tight transition-transform ${animate ? 'scale-110' : 'scale-100'}`}
          style={{ transition: 'transform 0.3s ease-out' }}>
          {stats.total_registrations.toLocaleString('en-IN')}
        </div>
        <p className="text-saffron-400 text-base mt-2">महिलाएं पंजीकृत</p>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <MetricCard
          icon={<MapPin size={24} />}
          label={t('districts_covered')}
          value={stats.districts.toString()}
          color="blue"
        />
        <MetricCard
          icon={<Award size={24} />}
          label={t('schemes_matched')}
          value={stats.total_matches.toLocaleString('en-IN')}
          color="green"
        />
        <MetricCard
          icon={<IndianRupee size={24} />}
          label={t('total_benefit_unlocked')}
          value={`₹${formatLakhs(stats.total_benefit)}`}
          color="saffron"
        />
        <MetricCard
          icon={<TrendingUp size={24} />}
          label="Avg Schemes/Woman"
          value={stats.total_registrations > 0
            ? (stats.total_matches / stats.total_registrations).toFixed(1)
            : '0'}
          color="purple"
        />
      </div>

      {/* Demographics Row */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <DemoCard icon={<Shield size={20} />} label="BPL" value={stats.bpl_count} />
        <DemoCard icon={<Baby size={20} />} label="गर्भवती" value={stats.pregnant_count} />
        <DemoCard icon={<Heart size={20} />} label="विधवा" value={stats.widow_count} />
      </div>

      {/* District Breakdown */}
      {stats.by_district.length > 0 && (
        <div className="bg-white/10 rounded-2xl p-5 backdrop-blur-sm">
          <h2 className="text-lg font-semibold mb-4 text-saffron-200">जिला-वार पंजीकरण</h2>
          <div className="space-y-3">
            {stats.by_district.slice(0, 10).map(([district, count]) => {
              const pct = stats.total_registrations > 0
                ? (count / stats.total_registrations) * 100
                : 0
              return (
                <div key={district} className="flex items-center gap-3">
                  <span className="text-sm text-saffron-200 w-32 capitalize">{district.replace(/_/g, ' ')}</span>
                  <div className="flex-1 h-7 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-saffron-500 to-saffron-400 rounded-full flex items-center justify-end pr-2 transition-all duration-700"
                      style={{ width: `${Math.max(pct, 8)}%` }}
                    >
                      <span className="text-xs font-bold">{count}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="text-center mt-10 text-saffron-400/60 text-xs">
        महिला एवं बाल विकास विभाग, छत्तीसगढ़ शासन • Powered by Saashakti
      </div>
    </div>
  )
}

function MetricCard({ icon, label, value, color }: {
  icon: React.ReactNode, label: string, value: string, color: string
}) {
  const bgMap: Record<string, string> = {
    blue: 'from-blue-500/20 to-blue-600/10 border-blue-400/30',
    green: 'from-green-500/20 to-green-600/10 border-green-400/30',
    saffron: 'from-saffron-500/20 to-saffron-600/10 border-saffron-400/30',
    purple: 'from-purple-500/20 to-purple-600/10 border-purple-400/30',
  }
  return (
    <div className={`bg-gradient-to-br ${bgMap[color]} border rounded-xl p-4`}>
      <div className="text-saffron-200 mb-2">{icon}</div>
      <p className="text-3xl font-bold">{value}</p>
      <p className="text-xs text-saffron-300 mt-1">{label}</p>
    </div>
  )
}

function DemoCard({ icon, label, value }: { icon: React.ReactNode, label: string, value: number }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
      <div className="flex justify-center text-saffron-300 mb-1">{icon}</div>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs text-saffron-300">{label}</p>
    </div>
  )
}

function formatLakhs(n: number): string {
  if (n >= 10000000) return `${(n / 10000000).toFixed(1)} Cr`
  if (n >= 100000) return `${(n / 100000).toFixed(1)} L`
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`
  return n.toString()
}
