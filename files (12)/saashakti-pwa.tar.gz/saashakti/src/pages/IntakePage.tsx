import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useLang } from '../hooks/useLang'
import { matchSchemes, calculateTotalBenefit } from '../engine/matchSchemes'
import { saveBeneficiary, saveMatches } from '../lib/supabase'
import type { BeneficiaryProfile, FieldWorker, SchemeMatch, FormStep } from '../engine/types'
import schemesData from '../data/schemes.json'
import districts from '../data/districts-cg.json'
import { ChevronRight, ChevronLeft, Heart, Home, Wallet, Users, AlertTriangle } from 'lucide-react'

interface Props {
  fieldWorker: FieldWorker | null
  onComplete: (profile: BeneficiaryProfile, matches: SchemeMatch[]) => void
}

const INITIAL: Partial<BeneficiaryProfile> = {
  gender: 'female',
  state: 'Chhattisgarh',
  residence_type: 'rural',
  caste_category: 'general',
  marital_status: 'married',
  income_bracket: 'below_1l',
  is_bpl: false,
  has_ration_card: false,
  has_bank_account: false,
  has_jan_dhan_account: false,
  owns_land: false,
  owns_pucca_house: false,
  has_lpg_connection: false,
  num_children: 0,
  is_pregnant: false,
  is_lactating: false,
  has_girl_child: false,
  is_shg_member: false,
  has_paid_maternity_leave: false,
  is_govt_psu_employee: false,
  family_is_taxpayer: false,
  family_govt_employee: false,
  family_is_elected_rep: false,
  family_is_board_chair: false,
  has_disability: false,
}

export default function IntakePage({ fieldWorker, onComplete }: Props) {
  const { t, lang } = useLang()
  const navigate = useNavigate()
  const [step, setStep] = useState<FormStep>(1)
  const [form, setForm] = useState<Partial<BeneficiaryProfile>>(INITIAL)
  const [saving, setSaving] = useState(false)

  const set = (key: string, value: unknown) => setForm(prev => ({ ...prev, [key]: value }))

  const canProceed = () => {
    if (step === 1) return form.name && form.age && form.district
    return true
  }

  const handleSubmit = async () => {
    const profile = form as BeneficiaryProfile
    const matches = matchSchemes(profile, schemesData.schemes as any)
    const totalBenefit = calculateTotalBenefit(matches)
    profile.total_schemes_matched = matches.filter(m => m.eligibility_status === 'eligible').length
    profile.total_annual_benefit = totalBenefit

    // Try to save to Supabase
    setSaving(true)
    try {
      const saved = await saveBeneficiary({
        ...profile,
        field_worker_id: fieldWorker?.id || null,
      })
      if (saved?.id) {
        await saveMatches(
          saved.id,
          matches
            .filter(m => m.eligibility_status === 'eligible' || m.eligibility_status === 'partial')
            .map(m => ({
              scheme_id: m.scheme_id,
              scheme_name_hi: m.scheme.name_hi,
              scheme_name_en: m.scheme.name_en,
              benefit_amount: m.scheme.benefit.amount,
              benefit_frequency: m.scheme.benefit.frequency,
              confidence: m.eligibility_status,
            }))
        )
      }
    } catch (err) {
      console.error('Save failed:', err)
      // Continue anyway — matching still works client-side
    }
    setSaving(false)

    onComplete(profile, matches)
    navigate('/results')
  }

  const StepIndicators = () => (
    <div className="flex items-center justify-center gap-2 py-4">
      {([1,2,3,4,5] as FormStep[]).map(s => (
        <div key={s} className={`step-indicator ${
          s === step ? 'bg-saffron-500 text-white' :
          s < step ? 'bg-success-500 text-white' :
          'bg-saffron-100 text-saffron-400'
        }`}>
          {s < step ? '✓' : s}
        </div>
      ))}
    </div>
  )

  const Toggle = ({ label, value, onChange }: { label: string, value: boolean, onChange: (v: boolean) => void }) => (
    <div className="flex items-center justify-between py-3">
      <span className="text-base">{label}</span>
      <div className="flex gap-2">
        <button onClick={() => onChange(true)}
          className={`toggle-option px-5 text-sm ${value ? 'toggle-active' : 'toggle-inactive'}`}>
          {t('yes')}
        </button>
        <button onClick={() => onChange(false)}
          className={`toggle-option px-5 text-sm ${!value ? 'toggle-active' : 'toggle-inactive'}`}>
          {t('no')}
        </button>
      </div>
    </div>
  )

  const OptionGrid = ({ options, value, onChange }: {
    options: { key: string, label: string, icon?: React.ReactNode }[],
    value: string, onChange: (v: string) => void
  }) => (
    <div className="grid grid-cols-2 gap-3">
      {options.map(o => (
        <button key={o.key} onClick={() => onChange(o.key)}
          className={`toggle-option flex-col gap-1 py-4 ${value === o.key ? 'toggle-active' : 'toggle-inactive'}`}>
          {o.icon}
          <span className="text-sm">{o.label}</span>
        </button>
      ))}
    </div>
  )

  return (
    <div className="pb-24">
      <StepIndicators />

      <div className="px-4 space-y-4">
        {/* STEP 1: Personal */}
        {step === 1 && (
          <div className="card space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <User size={20} className="text-saffron-500" /> {t('personal_details')}
            </h2>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">{t('name')}</label>
              <input value={form.name || ''} onChange={e => set('name', e.target.value)}
                className="input-field" placeholder={lang === 'hi' ? 'पूरा नाम' : 'Full Name'} />
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">{t('age')} ({t('years')})</label>
              <input type="number" inputMode="numeric" value={form.age || ''}
                onChange={e => set('age', parseInt(e.target.value) || 0)}
                className="input-field" placeholder="25" min={1} max={120} />
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">{t('phone_optional')}</label>
              <input type="tel" inputMode="tel" value={form.phone || ''}
                onChange={e => set('phone', e.target.value)}
                className="input-field" placeholder="9876543210" />
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">{t('district')}</label>
              <select value={form.district || ''} onChange={e => set('district', e.target.value)}
                className="select-field">
                <option value="">{t('select_district')}</option>
                {districts.map(d => (
                  <option key={d.code} value={d.code}>
                    {lang === 'hi' ? d.name_hi : d.name_en}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">{t('residence')}</label>
              <div className="flex gap-3">
                {(['rural','urban'] as const).map(r => (
                  <button key={r} onClick={() => set('residence_type', r)}
                    className={`toggle-option ${form.residence_type === r ? 'toggle-active' : 'toggle-inactive'}`}>
                    {r === 'rural' ? '🏡' : '🏙️'} {t(r)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Social */}
        {step === 2 && (
          <div className="card space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Users size={20} className="text-saffron-500" /> {t('social_details')}
            </h2>
            <div>
              <label className="text-sm text-gray-500 mb-2 block">{t('marital_status')}</label>
              <OptionGrid
                value={form.marital_status || 'married'}
                onChange={v => set('marital_status', v)}
                options={[
                  { key: 'married', label: t('married') },
                  { key: 'unmarried', label: t('unmarried') },
                  { key: 'widow', label: t('widow') },
                  { key: 'divorced', label: t('divorced') },
                  { key: 'deserted', label: t('deserted') },
                ]}
              />
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-2 block">{t('caste_category')}</label>
              <OptionGrid
                value={form.caste_category || 'general'}
                onChange={v => set('caste_category', v)}
                options={[
                  { key: 'general', label: t('general') },
                  { key: 'obc', label: t('obc') },
                  { key: 'sc', label: t('sc') },
                  { key: 'st', label: t('st') },
                ]}
              />
            </div>
          </div>
        )}

        {/* STEP 3: Economic */}
        {step === 3 && (
          <div className="card space-y-3">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Wallet size={20} className="text-saffron-500" /> {t('economic_details')}
            </h2>
            <div>
              <label className="text-sm text-gray-500 mb-2 block">{t('income')}</label>
              <OptionGrid
                value={form.income_bracket || 'below_1l'}
                onChange={v => set('income_bracket', v)}
                options={[
                  { key: 'below_1l', label: t('below_1l') },
                  { key: '1l_to_2l', label: t('1l_to_2l') },
                  { key: '2l_to_5l', label: t('2l_to_5l') },
                  { key: 'above_5l', label: t('above_5l') },
                ]}
              />
            </div>
            <Toggle label={t('bpl')} value={form.is_bpl || false} onChange={v => set('is_bpl', v)} />
            <Toggle label={t('has_ration_card')} value={form.has_ration_card || false} onChange={v => set('has_ration_card', v)} />
            <Toggle label={t('has_bank_account')} value={form.has_bank_account || false} onChange={v => set('has_bank_account', v)} />
            <Toggle label={t('jan_dhan')} value={form.has_jan_dhan_account || false} onChange={v => set('has_jan_dhan_account', v)} />
            <Toggle label={t('owns_land')} value={form.owns_land || false} onChange={v => set('owns_land', v)} />
            <Toggle label={t('owns_house')} value={form.owns_pucca_house || false} onChange={v => set('owns_pucca_house', v)} />
            <Toggle label={t('has_lpg')} value={form.has_lpg_connection || false} onChange={v => set('has_lpg_connection', v)} />
          </div>
        )}

        {/* STEP 4: Family */}
        {step === 4 && (
          <div className="card space-y-3">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Heart size={20} className="text-saffron-500" /> {t('family_details')}
            </h2>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">{t('children')}</label>
              <input type="number" inputMode="numeric" value={form.num_children || 0}
                onChange={e => set('num_children', parseInt(e.target.value) || 0)}
                className="input-field" min={0} max={15} />
            </div>
            <Toggle label={t('pregnant')} value={form.is_pregnant || false} onChange={v => set('is_pregnant', v)} />
            <Toggle label={t('lactating')} value={form.is_lactating || false} onChange={v => set('is_lactating', v)} />
            <Toggle label={t('has_girl_child')} value={form.has_girl_child || false} onChange={v => set('has_girl_child', v)} />
            {form.has_girl_child && (
              <div>
                <label className="text-sm text-gray-500 mb-1 block">{t('girl_child_age')}</label>
                <input type="number" inputMode="numeric" value={form.girl_child_age || ''}
                  onChange={e => set('girl_child_age', parseInt(e.target.value) || 0)}
                  className="input-field" min={0} max={25} />
              </div>
            )}
            <Toggle label={t('shg_member')} value={form.is_shg_member || false} onChange={v => set('is_shg_member', v)} />
            <Toggle label={t('disability')} value={form.has_disability || false} onChange={v => set('has_disability', v)} />
          </div>
        )}

        {/* STEP 5: Exclusions */}
        {step === 5 && (
          <div className="card space-y-3">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <AlertTriangle size={20} className="text-saffron-500" /> {t('exclusion_checks')}
            </h2>
            <p className="text-sm text-gray-500">
              {lang === 'hi'
                ? 'कृपया बताएं कि क्या निम्नलिखित में से कोई स्थिति आपके परिवार पर लागू होती है:'
                : 'Please indicate if any of the following apply to your family:'}
            </p>
            <Toggle label={t('family_taxpayer')} value={form.family_is_taxpayer || false} onChange={v => set('family_is_taxpayer', v)} />
            <Toggle label={t('family_govt_emp')} value={form.family_govt_employee || false} onChange={v => set('family_govt_employee', v)} />
            <Toggle label={t('family_elected')} value={form.family_is_elected_rep || false} onChange={v => set('family_is_elected_rep', v)} />
          </div>
        )}
      </div>

      {/* Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-saffron-200 p-4 flex gap-3">
        {step > 1 && (
          <button onClick={() => setStep((step - 1) as FormStep)}
            className="btn-secondary flex items-center justify-center gap-1 flex-shrink-0 w-28">
            <ChevronLeft size={18} /> {t('back')}
          </button>
        )}
        {step < 5 ? (
          <button onClick={() => setStep((step + 1) as FormStep)}
            disabled={!canProceed()}
            className="btn-primary flex items-center justify-center gap-1 flex-1">
            {t('next')} <ChevronRight size={18} />
          </button>
        ) : (
          <button onClick={handleSubmit} disabled={saving}
            className="btn-success flex-1 flex items-center justify-center gap-2">
            {saving ? t('loading') : t('submit')}
          </button>
        )}
      </div>
    </div>
  )
}

function User({ size, className }: { size: number, className?: string }) {
  return <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
}
