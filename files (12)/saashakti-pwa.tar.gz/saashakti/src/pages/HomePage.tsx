import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useLang } from '../hooks/useLang'
import { verifyFieldWorker } from '../lib/supabase'
import type { FieldWorker } from '../engine/types'
import { Users, User, Shield, Globe } from 'lucide-react'

interface Props {
  onFieldWorkerLogin: (fw: FieldWorker) => void
}

export default function HomePage({ onFieldWorkerLogin }: Props) {
  const { lang, setLang, t } = useLang()
  const navigate = useNavigate()
  const [showLogin, setShowLogin] = useState(false)
  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleWorkerLogin = async () => {
    if (code.length < 4) return
    setLoading(true)
    setError('')
    try {
      const worker = await verifyFieldWorker(code)
      if (worker) {
        onFieldWorkerLogin(worker as FieldWorker)
        navigate('/register')
      } else {
        setError(t('invalid_code'))
      }
    } catch {
      setError('Connection error. Please try again.')
    }
    setLoading(false)
  }

  const handleBeneficiary = () => {
    navigate('/register')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-saffron-50 to-saffron-100 flex flex-col">
      {/* Language toggle */}
      <div className="flex justify-end p-4">
        <button
          onClick={() => setLang(lang === 'hi' ? 'en' : 'hi')}
          className="flex items-center gap-1 px-3 py-2 rounded-lg bg-white/80 text-saffron-700 text-sm font-medium"
        >
          <Globe size={16} />
          {lang === 'hi' ? 'English' : 'हिंदी'}
        </button>
      </div>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-8">
        <div className="w-20 h-20 bg-saffron-500 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
          <span className="text-white font-bold text-3xl">स</span>
        </div>
        <h1 className="text-3xl font-bold text-saffron-800 mb-1">{t('app_name')}</h1>
        <p className="text-saffron-600 text-lg mb-10">{t('app_tagline')}</p>

        {!showLogin ? (
          <div className="w-full max-w-sm space-y-4">
            <button
              onClick={() => setShowLogin(true)}
              className="btn-primary flex items-center justify-center gap-3"
            >
              <Shield size={22} />
              {t('i_am_field_worker')}
            </button>
            <button
              onClick={handleBeneficiary}
              className="btn-secondary flex items-center justify-center gap-3"
            >
              <User size={22} />
              {t('i_am_beneficiary')}
            </button>
          </div>
        ) : (
          <div className="w-full max-w-sm space-y-4">
            <div className="card">
              <label className="block text-sm font-medium text-gray-600 mb-2">
                {t('enter_access_code')}
              </label>
              <input
                type="number"
                inputMode="numeric"
                pattern="[0-9]*"
                value={code}
                onChange={e => { setCode(e.target.value); setError('') }}
                className="input-field text-center text-2xl tracking-[0.3em] font-mono"
                placeholder="••••••"
                maxLength={6}
                autoFocus
              />
              {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </div>
            <button
              onClick={handleWorkerLogin}
              disabled={code.length < 4 || loading}
              className="btn-primary"
            >
              {loading ? t('loading') : t('verify')}
            </button>
            <button
              onClick={() => { setShowLogin(false); setCode(''); setError('') }}
              className="w-full text-center text-saffron-600 py-2"
            >
              {t('back')}
            </button>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="text-center pb-6 text-xs text-saffron-400">
        महिला एवं बाल विकास विभाग, छत्तीसगढ़
      </div>
    </div>
  )
}
