import { Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import type { FieldWorker, BeneficiaryProfile, SchemeMatch } from './engine/types'
import HomePage from './pages/HomePage'
import IntakePage from './pages/IntakePage'
import ResultsPage from './pages/ResultsPage'
import DashboardPage from './pages/DashboardPage'
import Header from './components/layout/Header'

export default function App() {
  const [fieldWorker, setFieldWorker] = useState<FieldWorker | null>(null)
  const [profile, setProfile] = useState<BeneficiaryProfile | null>(null)
  const [matches, setMatches] = useState<SchemeMatch[]>([])

  return (
    <div className="min-h-screen bg-saffron-50">
      <Routes>
        <Route path="/" element={
          <HomePage onFieldWorkerLogin={setFieldWorker} />
        } />
        <Route path="/register" element={
          <>
            <Header fieldWorker={fieldWorker} />
            <IntakePage
              fieldWorker={fieldWorker}
              onComplete={(p, m) => { setProfile(p); setMatches(m) }}
            />
          </>
        } />
        <Route path="/results" element={
          <>
            <Header fieldWorker={fieldWorker} />
            <ResultsPage
              profile={profile}
              matches={matches}
              fieldWorker={fieldWorker}
              onRegisterNext={() => { setProfile(null); setMatches([]) }}
            />
          </>
        } />
        <Route path="/dashboard" element={
          <DashboardPage />
        } />
      </Routes>
    </div>
  )
}
